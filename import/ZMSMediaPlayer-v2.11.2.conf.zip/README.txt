ZMSMediaPlayer 2.11
http://cmess.org/zmsmediaplayer

Produced by 
Christian Meier, http://christianmeier.info

Powered by 
JW PLAYERS, http://jeroenwijering.com
SWFObject, http://blog.deconcept.com/swfobject
ZMS, http://www.zms-publishing.com
ZOPE, http://zope.org
PYTHON, http://python.org
ICONS, http://famfamfam.com

LICENSE: Creative Commons Attribution-Share Alike 2.0 Germany
http://creativecommons.org/licenses/by-sa/2.0/de/

--------------------------------------------------------------
HISTORY

v2.11.0 20080329 [fh]
- major: made compatible to new object model of ZMS 2.11+
         may not run on lower versions

v2.0.0.20080112
- major: updated to JW PLAYERS 3.13
- major: changed licensing to CC_BY-SA
bundled with ZMS using a unrestricted licence for both JW PLAYERS and ZMS-Add-on to allow commercial usage out of the box

v1.0.2b.20071206
- minor: removed manage_lang (contributed by fh)
v1.0.2.20070422
- imagegallery: ZMI overview added (contributed by fh)
v1.0.1.20070417
- bugfix: in playlist.xml replaced .getHref(request) by .absolute_url() as problems with additional URL occurred (reported by tf)
v1.0.0.20070311
- initial public realease

v0.9.2.20070311
- minor: interface improvements
v0.9.1.20070308
- bugfix: in playlist.xml split &id= from rtmp-link for inserting as <identifier>
- bugfix: in playlist.xml set default values needed for external and streaming link
v0.9.0.20070225
- feature: upgraded to FLASH PLAYERS 3.5 with UFO 3.21
- feature: added VideoPlayer for FLV and RTMP streams as mediaurl

v0.8.3.20070223
- feature: added metadict ('Hide Mediaplayers?' meta-attribute in ZMSFolders/Documents)
  the attr_mediaplayer_hidden can be overridden by a REQUEST-variable hidemediaplayer
  (e.g. in [pageregion_before]: <dtml-call "REQUEST.set('hidemediaplayer',_.True)">)
v0.8.2.20070223
- bugfix: if external playlist.xml could not be load
- feature: added langdict for multilingual support (ger, eng)
- feature: added metacmd manage_emptyMediaContainer
- feature: improved direct-nav in imagegallery.showdetailview for long lists
v0.8.1.20070218
- bugfix: added utf-8 to fullscreen.html
v0.8.0.20070217
- feature: append tracks of an external playlist.xml (XML Shareable Playlist Format, http://xspf.org/xspf-v1.html)
- feature: added direct-nav in imagegallery.showdetailview

v0.7.0.20070213
- feature: added headScript_Mediaplayer
- feature: changed direct/additional resource handling
 (added default MediaContainer in players [mediafiles]
  changed URL in players to Additional URL [mediaurl]
  removed Additional URL in MediaContainer)

v0.6.0.20070208
v0.5.0.20070205
v0.4.0.20070203
v0.3.0.20070202
v0.2.0.20070127
v0.1.0.20070126
--------------------------------------------------------------

